#include <stdio.h>
#include <stdlib.h>
#include "arvores.h"

Tree* criaArvore(){ //Função que cria uma árvore vazia
    Tree* t = (Tree*) malloc(sizeof(Tree));

    if (t != NULL){
        t -> raiz = NULL;
    }

    return t;
}


int insereFolha(Tree* t, int v){ //Função que criará e inserirá uma nova folha á árvore

    if (t == NULL) return 0;

    Node* n = (Node*) malloc(sizeof(Node));

    if (n != NULL){
        n -> esq = NULL;
        n -> dir = NULL;
        n -> head = NULL;
        n -> d = v;
    }else{
        return 0;
    }

    if (t -> raiz == NULL){ //Caso a árvore esteja vazia, o primeiro nó será n
        t -> raiz = n;
        return 1;
    }

    Node* p = t -> raiz; //Ponteiro que percorrerá a árvore até chegar ás folhas
    int valido = 0; //Caso se encontre um valor igual ao novo pretendido, o novo nó não é adicionado

    while (p != NULL){
        n -> head = p;

        if (p -> d == v){
            valido = 1;
            break;
        }

        if (p -> d > v){
            p = p -> esq;
        }else{
            p = p -> dir;
        }
    }

    if (valido == 1){
        free(n);
        return 0;
    }

    if (n -> head -> d > v){
        n -> head -> esq = n;
    }else{
        n -> head -> dir = n;
    }

    return 1;
}

void printaArvore(Tree* t){


}

