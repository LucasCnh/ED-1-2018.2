#ifndef TAD_ARVORE
#define TAD_ARVORE


typedef struct _Node_ { //Nó que representará um dos filhos da árvore
    struct _Node_* esq; //Filho á esquerda do nó atual
    struct _Node_* dir; //Filho á direita do nó atual
    struct _Node_* head; //Pai do nó atual
    int d; //Dado do nó
}Node;

typedef struct _Tree_ { //Estrutura que guardará o início da árvore
    Node* raiz; //Início da árvore
}Tree;

/**
@criaArvore()
@brief função que cria uma árvore vazia
@return estrutura do tipo Tree (árvore) vazia
*/
Tree* criaArvore();

/**
@insereFolha(Tree* t, int v)
@brief função que insere uma nova folha á árvore
@param t estrutura do tipo Tree (árvore) a ser inserido o novo dado (folha)
@param v dado á ser inserido em estrutura do tipo árvore como uma folha
@return 1 caso a inserção tenha sido bem-sucedida, 0 caso contrário
*/
int insereFolha(Tree* t, int v);

/**
@printaArvore(Tree* t)
*/
void printaArvore(Tree* t);

#endif
