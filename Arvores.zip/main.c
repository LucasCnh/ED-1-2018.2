#include <stdio.h>
#include "arvores.h"

int main(){

    Tree* t = criaArvore();

    printf("%i", insereFolha(t, 7));
    printf("%i", insereFolha(t, 7));
    printf("%i", insereFolha(t, 8));
    printf("%i", insereFolha(t, 9));
    printf("%i", insereFolha(t, 5));
    printf("%i", insereFolha(t, 3));
    printf("%i", insereFolha(t, 9));
    printf("%i", insereFolha(t, 4));
    
    return 0;
}
