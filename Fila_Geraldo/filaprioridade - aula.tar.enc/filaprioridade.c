//===================fila.h==========//
typedef struct _fila_{
	int *mat;
	int qtd;
	int primeiro;
	int ultimo;
	int tamanho;
}fila;

typedef struct _coordenacao_{
	fila *p; // fila prioridade
	fila *n; // fila normal
	int peso;

}coord;

//==================fila.c===============//
int enqueue(fila *f, int aluno){ // enfileriar
	if (f!= NULL){
		if (f -> primeiro != f -> ultimo){
			f->mat[f->ult] = aluno;

			f->ultimo = (f->ultimo+1) % f->tam;
			if (f->primeiro < 0){
				f-> primeiro = 0;
			f -> qtd ++;
			return 1;
			}
		}
		return 0;
	}
}

int dequeue (fila *f){ // retirar elementos 
	if ((f!= NULL) && (f ->qtd>0)){
		int tmp = f->mat[f->prim];
		f -> prim = (f->prim+1) % f-> tam;
		f -> qtd --;
		return tmp;
	}
	return -1;
}

int insereCoordenacao(fila_coordenacao *c, int aluno, int prioridade){

	if (prioridade)
		return enqueue(c->p, aluno);

	return enqueue(c -> n, aluno);

}

int atender(fila_coord *c){
	if (c -> peso <3) &&(c->p->qtd >0){
		c->peso++;

		return dequeue(c->);
	}

	c-> peso = 0;
	return dequeue(c->n);


}


//=======================main.c==============//

fila _coord *filas;
